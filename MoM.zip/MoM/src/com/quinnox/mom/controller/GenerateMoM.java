package com.quinnox.mom.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.quinnox.mom.dao.MomDAO;
import com.quinnox.mom.model.Actions;
import com.quinnox.mom.model.Mom;
import com.quinnox.mom.model.Participants;

@WebServlet("/GenerateMoM")
public class GenerateMoM extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public GenerateMoM() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
		PrintWriter out = response.getWriter();
		
		String subject = request.getParameter("subject");
		String purpose = request.getParameter("purpose");
		String startTime = request.getParameter("startTime");
		String endTime = request.getParameter("endTime");
		String scid = request.getParameter("creatorId");
		String pd = request.getParameter("pd");
		String dt = request.getParameter("dt");
		int creatorId = Integer.parseInt(scid);
		ArrayList<Mom> mom_list = new ArrayList<>();

		Mom momObj = new Mom();

		momObj.setCreator_id(creatorId);
		momObj.setDecisionTaken(dt);
		momObj.setPointsDiscussed(pd);
		momObj.setMom_purpose(purpose);
		momObj.setMom_sub(subject);
		momObj.setMom_e_date(endTime);
		momObj.setMom_s_date(startTime);

		mom_list.add(momObj);

		ArrayList<Participants> part_list = new ArrayList<>();

		for (int i = 1; i < 15; i++) {

			String sempId;
			String attendance;
			sempId = request.getParameter("part" + i);
			attendance = request.getParameter("attendance" + i);

			if (sempId != null && attendance != null) {
				int empId = Integer.parseInt(sempId);
				System.out.println(sempId);

				Participants partObj = new Participants();

				partObj.setEmp_id(empId);
				partObj.setAttendance(attendance);

				part_list.add(partObj);
			} else {
				break;
			}

		}
		ArrayList<Actions> actions_list = new ArrayList<>();

		for (int i = 1; i < 15; i++) {
			String action_name = request.getParameter("actionItem" + i);
			String action_owner = request.getParameter("actionOwner" + i);
			System.out.println(action_name);
			System.out.println(action_owner);
			if (action_name != null && action_owner != null) {
				Actions actObj = new Actions();

				actObj.setActionName(action_name);
				actObj.setAssignedTo(Integer.parseInt(action_owner));

				actions_list.add(actObj);
			} else {
				break;
			}
		}

		boolean insertedData = MomDAO.insertMom(mom_list, part_list, actions_list,request);

		if (insertedData == true)
		{
				HttpSession session = request.getSession();
				session.setAttribute("momCS", "true");
				response.sendRedirect("Dashboard.jsp");
		}
		else
		{
			HttpSession session = request.getSession();
			String desg = session.getAttribute("desg").toString();
			System.out.println(desg);
			if(desg.equals("admin")){
			response.sendRedirect("GenerateMomFinalAdmin.jsp");}
			if(desg.equals("trainee"))
			{
				response.sendRedirect("GenerateMomFinal.jsp");
			}

		}
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}