package com.quinnox.mom.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.quinnox.mom.dao.MomDAO;
import com.quinnox.mom.model.Actions;
import com.quinnox.mom.model.Mom;


@WebServlet("/MomView")
public class MomView extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public MomView() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		HttpSession session = request.getSession();
		String sid = session.getAttribute("id").toString();

		int id = Integer.parseInt(sid);
		System.out.println(id);
		
		String smom_id = request.getParameter("momid");
		
		int mom_id = Integer.parseInt(smom_id);
		
		System.out.println(mom_id);
		
		ArrayList<Mom> momDetails = new ArrayList<Mom>();
		ArrayList<Mom> momAllDetails = new ArrayList<Mom>();
		
		 momAllDetails = MomDAO.getAllMomDeatils(momDetails, mom_id);
		
			response.sendRedirect("ViewMom.jsp");
			
	
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
