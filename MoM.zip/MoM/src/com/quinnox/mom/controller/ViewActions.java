package com.quinnox.mom.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.quinnox.mom.dao.MomDAO;

/**
 * Servlet implementation class ViewActions
 */
@WebServlet("/ViewActions")
public class ViewActions extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ViewActions() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		

		String sid = request.getParameter("empId");
		int id = Integer.parseInt(sid);
		System.out.println(sid);
		
		ArrayList actionsList = new ArrayList();
		ArrayList resultsList = new ArrayList();
		
		resultsList = MomDAO.getActionDetails(actionsList,id);
		 
		 for(Object rs : resultsList)
		 {
			 System.out.println(rs);
		 }

		HttpSession session = request.getSession(true);
		
		session.setAttribute("id",id );
	session.setAttribute("actionsList", resultsList);
	
	response.sendRedirect("viewActions.jsp");
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
