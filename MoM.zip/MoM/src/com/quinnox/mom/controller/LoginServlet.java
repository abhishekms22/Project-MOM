package com.quinnox.mom.controller;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.quinnox.mom.dao.EmployeeDAO;
import com.quinnox.mom.dao.LoginDAO;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public LoginServlet() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		String email = request.getParameter("email");
		String pass = request.getParameter("pass");
		HttpSession session = request.getSession();
		PrintWriter out = response.getWriter();

		if (LoginDAO.validate(email, pass)) {
			HttpSession session1 = request.getSession(true);
			session1.setMaxInactiveInterval(30*60);
			int id = LoginDAO.getEmpId(email, pass);
			session1.setAttribute("id", id);
			String empDesg = LoginDAO.getEmpdesg(email, pass);
			String empName = EmployeeDAO.getEmpName(email,pass);
			System.out.println(empName);
			session1.setAttribute("desg", empDesg);
			session1.setAttribute("name", empName);
//			if ((empDesg.equals("Admin")) || (empDesg.equals("admin"))) {
//				session1.setAttribute("emp_email", email);
//				session1.setAttribute("id", id);
//				session1.setAttribute("desg", empDesg);
//				// System.out.println(id);
//
				RequestDispatcher rd = request.getRequestDispatcher("Dashboard.jsp");
				rd.include(request, response);
//				System.out.println("login successfull as a admin");
//				
//
//				HttpSession hp=request.getSession();
//				hp.setAttribute("checkDesg", empDesg);
//				
//			} else {
//				session1.setAttribute("emp_email", email);
//				session1.setAttribute("id", id);
//
//				// System.out.println(id);
//
//				RequestDispatcher rd = request.getRequestDispatcher("EmployeeHome.jsp");
//				rd.include(request, response);
//				System.out.println("login successfull as a Employee");
//			}

		} else {
			HttpSession hp = request.getSession();

			hp.setAttribute("error", "Invalid Email/Password");
			hp.setMaxInactiveInterval(5);
			request.setAttribute("loginResult", "true");

			RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
			rd.include(request, response);
		}
		out.close();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}