package com.quinnox.mom.model;

import java.util.StringTokenizer;

public class Mom {
	private int mom_id;
	private String mom_sub;
	private String mom_s_date;
	private String mom_e_date;
	private int creator_id;
	private String mom_purpose;
	private String momCreateDt;
	public String getMomCreateDt() {
	
	  
		return momCreateDt;
	}
	public void setMomCreateDt(String momCreateDt) {
		this.momCreateDt = momCreateDt;
	}
	public String getMom_purpose() {
		return mom_purpose;
	}
	public void setMom_purpose(String mom_purpose) {
		this.mom_purpose = mom_purpose;
	}
	public int getCreator_id() {
		return creator_id;
	}
	public void setCreator_id(int creator_id) {
		this.creator_id = creator_id;
	}
	public int getMom_id() {
		return mom_id;
	}
	public void setMom_id(int mom_id) {
		this.mom_id = mom_id;
	}
	public String getMom_sub() {
		return mom_sub;
	}
	public void setMom_sub(String mom_name) {
		this.mom_sub = mom_name;
	}
	public String getMom_s_date() {
		return mom_s_date;
	}
	public void setMom_s_date(String mom_s_date) {
		this.mom_s_date = mom_s_date;
	}
	public String getMom_e_date() {
		return mom_e_date;
	}
	public void setMom_e_date(String mom_e_date) {
		this.mom_e_date = mom_e_date;
	}
	public String getPointsDiscussed() {
		return pointsDiscussed;
	}
	public void setPointsDiscussed(String pointsDiscussed) {
		this.pointsDiscussed = pointsDiscussed;
	}
	public String getDecisionTaken() {
		return decisionTaken;
	}
	public void setDecisionTaken(String decisionTaken) {
		this.decisionTaken = decisionTaken;
	}

	private String pointsDiscussed;
	private String decisionTaken;
	private String participants;

}
