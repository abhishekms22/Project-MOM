package com.quinnox.mom.model;

import java.nio.charset.StandardCharsets;
import java.sql.Date;
import java.util.Base64;

public class Employees {

	private int emp_id;
	private String emp_name;
	private String emp_email;

	private String emp_pass;
	private String emp_desgn;
	private int dept_id;
	private int emp_status;
	private String emp_startdate;

	public int getEmp_id() {
		return emp_id;
	}

	public void setEmp_id(int emp_id) {
		this.emp_id = emp_id;
	}

	public String getEmp_name() {
		return emp_name;
	}

	public void setEmp_name(String emp_name) {
		this.emp_name = emp_name;
	}

	public String getEmp_email() {
		return emp_email;
	}

	public void setEmp_email(String emp_email) {
		this.emp_email = emp_email;
	}

	public String getEmp_desgn() {
		return emp_desgn;
	}

	public void setEmp_desgn(String emp_desgn) {
		this.emp_desgn = emp_desgn;
	}

	public int getDept_id() {
		return dept_id;
	}

	public void setDept_id(int dept_id) {
		this.dept_id = dept_id;
	}

	public int getEmp_status() {
		return emp_status;
	}

	public void setEmp_status(int emp_status) {
		this.emp_status = emp_status;
	}

	public String getEmp_startdate() {
		return emp_startdate;
	}

	public void setEmp_startdate(String emp_startdate) {
		this.emp_startdate = emp_startdate;
	}

	public String getEmp_pass() {

//		String decodedString = this.emp_pass;
//		Base64.Decoder decoder = Base64.getDecoder();
//		byte[] decodedByteArray = decoder.decode(decodedString);
//		this.emp_pass= decodedByteArray.toString();
//		return emp_pass;
		return this.emp_pass;
	}

	public void setEmp_pass(String emp_pass) {

//		Base64.Encoder encoder = Base64.getEncoder();
//		String normalString = emp_pass;
//		String encodedString = encoder.encodeToString(normalString.getBytes(StandardCharsets.UTF_8));
		this.emp_pass=emp_pass;
	}

}
