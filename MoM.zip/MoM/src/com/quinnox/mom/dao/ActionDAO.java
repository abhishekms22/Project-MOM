package com.quinnox.mom.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.swing.plaf.synth.SynthSeparatorUI;

import com.quinnox.mom.model.Actions;

public class ActionDAO {
	public static boolean validate(String email, String pass) {
		boolean status = false;

		try {
			Connection con = EmployeeDAO.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from admin where ad_email=? and ad_pass=? ");

			ps.setString(1, email);
			ps.setString(2, pass);

			ResultSet rs = ps.executeQuery();
			status = rs.next();
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return status;
	}
	
	
	
	public static boolean changeStatus(String status,int id,int aid)
	{
		Connection con = null;
		int status1 = 0;
		try {
		 con = EmployeeDAO.getConnection();
			PreparedStatement pst = con.prepareStatement(" update actions set status = ? where emp_id = ? and action_id = ?");
			
			pst.setString(1, status);
			pst.setInt(2, id);
			pst.setInt(3, aid);
			status1 = pst.executeUpdate();
			 
			 
			con.close();

			 return true;

	}
		
		catch(Exception e)
		{
			System.out.println(e);
		return false;
		}
		
		
}




	public static int getActionID(int emp_id) {
		// TODO Auto-generated method stub
	
		
		int action_id = 0 ;

		try
		{
			Connection con = EmployeeDAO.getConnection();
			
			PreparedStatement ps = con.prepareStatement("select action_id from actions where emp_id= ?");
			ps.setInt(1, emp_id);
			
			ResultSet rs = ps.executeQuery();
			
			while(rs.next())
			{
				action_id = rs.getInt(1);
			}
			con.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return action_id;
	}
	public static ArrayList<Actions> getRFCActions(int empId)
	{
		ArrayList<Actions> gFA = new ArrayList<Actions>();
		try
		{
			Connection con = MomDAO.getConnection();
			PreparedStatement ps = con.prepareStatement("select action_id,action_name,status,emp_id from actions where status='RFC' and status NOT LIKE 'COMPLETED' and mom_id in (select mom_id from mom where creator_id = ?) ");
			ps.setInt(1, empId);
			
			ResultSet rs = ps.executeQuery();
			while(rs.next())
			{
				Actions a = new Actions();
				a.setActionId(rs.getInt(1));
				a.setActionName(rs.getString(2));
				a.setStatus(rs.getString(3));
				a.setAssignedTo(rs.getInt(4));
				gFA.add(a);
				
			}
			con.close();

		}

		catch(Exception e)
		{
			System.out.println(e);
		}
		return gFA;
	}



	public static boolean updateActionStatus(int id) {
		Connection con = null;
		int status = 0;
		try
		{
			 con = MomDAO.getConnection();
			
			
			PreparedStatement ps = con.prepareStatement("update actions set status='COMPLETED' where action_id=?");
			ps.setInt(1, id);
			
			status = ps.executeUpdate();
			
			con.close();

		}
		catch(Exception e)
		{
			System.out.println(e);
		return false;
	}

		if(status>0)
		{
			return true;

		}
		else{
		return false;
	}
	}
}