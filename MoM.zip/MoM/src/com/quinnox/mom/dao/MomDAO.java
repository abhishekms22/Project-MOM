package com.quinnox.mom.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.sql.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.quinnox.mom.model.Actions;
import com.quinnox.mom.model.Mom;
import com.quinnox.mom.model.Participants;

public class MomDAO {

	public static Connection getConnection() {
		Connection con = null;

		try {

			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("Connecting to database...");
			con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/xe", "adarsh", "adarsh");
		} catch (Exception e) {
			System.out.println(e);
		}
		return con;
	}

	public static boolean insertMom(ArrayList<Mom> mom_list, ArrayList<Participants> part_list,
			ArrayList<Actions> actions_list, HttpServletRequest request) {
		int mom_id = 0;
		try {
			Connection con = MomDAO.getConnection();
			PreparedStatement ps = con.prepareStatement("select count(*) from mom");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				mom_id = rs.getInt(1);
				mom_id = mom_id + 1;
			}
			System.out.println(mom_id);

			List<Integer> partListId = new ArrayList<>();
			List<String> partListAt = new ArrayList<String>();
			for (Participants part : part_list) {

				partListId.add(part.getEmp_id());
				partListAt.add(part.getAttendance());
			}

			HttpSession session = request.getSession();

			boolean sm = MomDAO.setMom(mom_list, mom_id);

			boolean sp = MomDAO.setParticipants(part_list, mom_id);
			if (!sp) {

				session.setAttribute("isValidPar", "Not a Valid Employee code");

			}


			boolean sc = MomDAO.setActionItems(actions_list, mom_id, request,partListId,partListAt);
			if (!sc) {
				session.setAttribute("isValidAct", "Not a valid Employee code!");
				
			}
			con.close();

			if (sm && sp && sc)
				return true;
			else
				return false;

		} catch (Exception e) {
			return false;

		}

	}

	private static boolean setMom(ArrayList<Mom> mom_list, int mom_id) {
		int status = 0;
		try {
			Connection con = MomDAO.getConnection();
			PreparedStatement ps = con.prepareStatement("insert into mom values(?,?,?,?,?,?,?,?,?)");

			ps.setInt(1, mom_id);

			for (Mom m : mom_list) {
				Timestamp ts = new Timestamp(System.currentTimeMillis());

				ps.setInt(2, m.getCreator_id());
				System.out.println("creator id is " + m.getCreator_id());
				ps.setString(3, m.getMom_purpose());
				ps.setString(4, m.getMom_sub());
				ps.setString(5, m.getMom_s_date());
				ps.setString(6, m.getMom_e_date());
				ps.setString(7, m.getPointsDiscussed());
				ps.setString(8, m.getDecisionTaken());
				ps.setDate(9, new Date(ts.getTime()));

			}
			status = 0;
			status = ps.executeUpdate();
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		if (status > 0)
			return true;
		else
			return false;

	}

	private static boolean setParticipants(ArrayList<Participants> part_list, int mom_id) {
		int status = 0;
		try {
			Connection con = MomDAO.getConnection();

			for (Participants pts : part_list) {
				status = 0;

				PreparedStatement ps = con.prepareStatement("insert into participants values(?,?,?)");
				ps.setInt(2, mom_id);

				ps.setInt(1, pts.getEmp_id());
				ps.setString(3, pts.getAttendance());
				status = ps.executeUpdate();
				System.out.println(status);
			}
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		if (status == 1)
			return true;
		else
			return false;
	}

	private static boolean setActionItems(ArrayList<Actions> actions_list, int mom_id, HttpServletRequest request,
			List<Integer> partListId,List<String> partListAt) {
		int action_id = 0;
		int status = 0;

		for (Actions ac : actions_list) {
			try {

				Connection con = MomDAO.getConnection();
				PreparedStatement pst = con.prepareStatement("select count(*) from actions");
				ResultSet rs = pst.executeQuery();
				while (rs.next())
					action_id = rs.getInt(1);
				action_id++;
				pst = con.prepareStatement("insert into actions values(?,?,?,?,?,?,?,?,?,?,?,?,?)");
				pst.setInt(1, action_id);
				pst.setString(2, ac.getActionName());
				pst.setInt(3, ac.getAssignedTo());
				pst.setString(4, ac.getStatus());
				pst.setInt(5, mom_id);
				pst.setTimestamp(6, new Timestamp(System.currentTimeMillis()));
				pst.setTimestamp(7, null);
				pst.setTimestamp(8, null);
				pst.setTimestamp(9, null);
				pst.setString(10, null);
				pst.setTimestamp(11, null);
				pst.setString(12, null);
				pst.setTimestamp(13, null);
				status = pst.executeUpdate();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return false;
			}
		}
		if (status == 1)
			return true;
		else
			return false;

	}

	public static ArrayList getMomDetails(ArrayList<String> momAList, int empId) {

		try {
			String momSub;

			Connection con = MomDAO.getConnection();

			PreparedStatement pst = con.prepareStatement(
					"select m.mom_sub from mom m,employees e, participants p where e.emp_id = p.emp_id and p.mom_id = m.mom_id and e.emp_id = ?");
			pst.setInt(1, empId);

			ResultSet rs = pst.executeQuery();

			while (rs.next()) {
				momAList.add(rs.getString(1));

			}
			con.close();

		} catch (Exception e) {
			System.out.println(e);
		}

		return momAList;

	}

	public static ArrayList getActionDetails(ArrayList actionsList, int id) {

		try {

			String action_name;

			Connection con = MomDAO.getConnection();

			PreparedStatement pst = con.prepareStatement(
					"select a.action_id, m.mom_sub,status from mom m,actions a, employees e where m.mom_id = a.mom_id and e.emp_id = a.emp_id and e.emp_id=?");
			pst.setInt(1, id);

			ResultSet rs = pst.executeQuery();

			while (rs.next()) {
				actionsList.add(rs.getInt(1));
				actionsList.add(rs.getString(2));
				actionsList.add(rs.getString(3));
			}

			con.close();
		}

		catch (Exception e) {
			System.out.println(e);
		}

		return actionsList;
	}

	public static ArrayList getActionStatus(ArrayList status, int id) {

		try {

			String action_name;

			Connection con = MomDAO.getConnection();

			PreparedStatement pst = con.prepareStatement("select status from actions where emp_id=?");
			pst.setInt(1, id);

			ResultSet rs = pst.executeQuery();

			while (rs.next()) {

				status.add(rs.getString(1));

			}
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return status;

	}

	public static List getActionDetailsForEmp(List<Actions> getActions, int id) {

		try {

			String action_name;
			Connection con = MomDAO.getConnection();

			PreparedStatement pst = con
					.prepareStatement("select action_id,action_name,emp_id,status from actions where emp_id=?");
			pst.setInt(1, id);

			ResultSet rs = pst.executeQuery();

			while (rs.next()) {
				Actions a = new Actions();

				a.setActionId(rs.getInt(1));
				a.setActionName(rs.getString(2));
				a.setAssignedTo(rs.getInt(3));
				a.setStatus(rs.getString(4));

				getActions.add(a);
			}
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return getActions;

	}

	public static ArrayList<Mom> getCreatorMom(int empId) {
		ArrayList createdMomList = new ArrayList();

		try {
			Connection con = MomDAO.getConnection();
			PreparedStatement ps = con
					.prepareStatement("select mom_id,mom_s_time,mom_purpose,createddt from mom where creator_id = ?");
			ps.setInt(1, empId);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				Mom m = new Mom();
				m.setMom_id(rs.getInt(1));
				m.setMom_s_date(rs.getString(2));
				m.setMom_purpose(rs.getString(3));
				m.setMomCreateDt(rs.getString(4));
				createdMomList.add(m);
			}
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return createdMomList;
	}

	public static ArrayList<Integer> getUserInfo(int emp_id) {
		int momsCreated = 0;
		int participatedIn = 0;
		ArrayList info = new ArrayList<>();
		try {
			Connection con = MomDAO.getConnection();
			PreparedStatement ps = con.prepareStatement("select count(*) from mom where creator_id = ?");
			ps.setInt(1, emp_id);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				momsCreated = rs.getInt(1);
				info.add(momsCreated);
			}
			PreparedStatement ps1 = con.prepareStatement("select count(*) from participants where emp_id = ?");
			ps1.setInt(1, emp_id);
			ResultSet rs1 = ps1.executeQuery();
			while (rs1.next()) {
				participatedIn = rs1.getInt(1);
				info.add(participatedIn);
			}

			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return info;
	}

	public static ArrayList<Mom> getAllMomDeatils(ArrayList<Mom> momDetails, int mom_id) {

		try {
			Connection con = MomDAO.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from mom where mom_id = ?");

			ps.setInt(1, mom_id);

			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				Mom m = new Mom();
				m.setCreator_id(rs.getInt(2));
				m.setMom_purpose(rs.getString(3));
				m.setMom_sub(rs.getString(4));
				m.setMom_s_date(rs.getString(5));
				m.setMom_e_date(rs.getString(6));
				m.setPointsDiscussed(rs.getString(7));
				m.setDecisionTaken(rs.getString(8));
				m.setMomCreateDt(rs.getString(9));
				momDetails.add(m);
			}
			con.close();
		}

		catch (Exception e) {
			System.out.println(e);
			return null;

		}
		return momDetails;
	}
}