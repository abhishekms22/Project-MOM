package com.quinnox.mom.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class LoginDAO {
	public static boolean validate(String email, String pass) {
		boolean status = false;

		try {
			Connection con = EmployeeDAO.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from employees where emp_email=? and emp_pass=?");

			ps.setString(1, email);
			ps.setString(2, pass);

			ResultSet rs = ps.executeQuery();
			status = rs.next();

		} catch (Exception e) {
			System.out.println(e);
		}
		return status;
	}

	public static int getEmpId(String email, String pass) {
		int id = 0;
		try {
			Connection con = EmployeeDAO.getConnection();
			PreparedStatement ps = con.prepareStatement("select emp_id from employees where emp_email=? and emp_pass=?");

			ps.setString(1, email);
			ps.setString(2, pass);

			ResultSet rs = ps.executeQuery();
			while(rs.next())
			{
			id = rs.getInt(1);
			}
			con.close();

		//	System.out.println(id);
		} catch (Exception e) {
			System.out.println(e);
			
		}
		return id;
	}
	public static String getEmpdesg(String email, String pass){
		String desg = null;
		try {
			Connection con = EmployeeDAO.getConnection();
			PreparedStatement ps = con.prepareStatement("select emp_desg from employees where emp_email=? and emp_pass=?");
			
			ps.setString(1, email);
			ps.setString(2, pass);
			
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				desg = rs.getString(1);
			}
			con.close();

		}
		catch(Exception e){
				e.printStackTrace();
			}
		
		return desg;
		
	}
}