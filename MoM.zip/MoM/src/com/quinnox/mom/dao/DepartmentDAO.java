package com.quinnox.mom.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.quinnox.mom.model.Departments;

public class DepartmentDAO {

	public static Connection getConnection() {
		Connection con = null;

		try {

			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("Connecting to database...");
			con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/xe", "adarsh", "adarsh");
		} catch (Exception e) {
			System.out.println(e);
		}
		return con;
	}
	public static List<Departments> getAllDepartments() {
		List<Departments> list = new ArrayList<Departments>();
		try {
			Connection con = DepartmentDAO.getConnection();

			PreparedStatement ps = con.prepareStatement("select * from departments");
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				Departments e = new Departments();
				e.setDept_id(rs.getInt(1));
				e.setDept_name(rs.getString(2));
				list.add(e);
			}
			con.close();

		} catch (Exception E) {
			System.out.println(E);
		}
		return list;
	}

}
