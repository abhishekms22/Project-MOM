package com.quinnox.mom.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.swing.plaf.synth.SynthSeparatorUI;

import com.quinnox.mom.dao.*;

import com.quinnox.mom.model.*;
import com.quinnox.mom.*;
//import com.quinnox.basics.dao.CustomerDAO;
//import com.quinnox.basics.dao.Exception;
//import com.quinnox.basics.dao.List;
//import com.quinnox.basics.dao.PreparedStatement;
//import com.quinnox.basics.dao.ResultSet;
//import com.quinnox.basics.model.Customer;
import com.quinnox.mom.model.Employees;

public class EmployeeDAO {

	public static Connection getConnection() {
		Connection con = null;

		try {

			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("Connecting to database...");
			con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/xe", "adarsh", "adarsh");
		} catch (Exception e) {
			System.out.println(e);
		}
		return con;
	}

	public static List<Employees> getAllEmployees() {
		List<Employees> list = new ArrayList<Employees>();
		try {
			Connection con = EmployeeDAO.getConnection();

			PreparedStatement ps = con.prepareStatement("select * from employees where emp_status = 1");
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				Employees e = new Employees();

				e.setEmp_id(rs.getInt(1));
				e.setEmp_name(rs.getString(2));
				e.setEmp_email(rs.getString(3));
				e.setEmp_pass(rs.getString(4));
				e.setEmp_desgn(rs.getString(5));
				e.setDept_id(rs.getInt(6));
				e.setEmp_status(rs.getInt(7));

				list.add(e);
			}
			con.close();

		} catch (Exception E) {
			System.out.println(E);
		}
		return list;
	}

	public static List<Employees> getNameAndId() {
		List<Employees> list = new ArrayList<Employees>();
		try {
			Connection con = EmployeeDAO.getConnection();

			PreparedStatement ps = con.prepareStatement("select emp_id,emp_name from employees");
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				Employees e = new Employees();

				e.setEmp_id(rs.getInt(1));
				e.setEmp_name(rs.getString(2));

				list.add(e);
			}
			con.close();

		} catch (Exception E) {
			System.out.println(E);
		}
		return list;
	}

	public static int updateEmployee(Employees empObj) {
		int status = 0;
		try {
			Connection con = EmployeeDAO.getConnection();
			PreparedStatement ps = con.prepareStatement(
					"update employees set emp_name=?, emp_pass=?,emp_email=?,emp_desg=?, Dept_id=? where emp_id=?");
			ps.setString(1, empObj.getEmp_name());
			ps.setString(3, empObj.getEmp_email());
			ps.setString(2, empObj.getEmp_pass());
			ps.setString(4, empObj.getEmp_desgn());
			ps.setInt(5, empObj.getDept_id());

			ps.setLong(6, empObj.getEmp_id());
			System.out.println("employee");
			System.out.println(empObj.getEmp_name());
			System.out.println(empObj.getEmp_id());

			status = ps.executeUpdate();
			con.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return status;
	}

	public static int insertEmployee(Employees e) {
		int status = 0;

		try {
			Connection con = EmployeeDAO.getConnection();
			PreparedStatement ps = con
					.prepareStatement("insert into employees values(employees_seq.NEXTVAL,?,?,?,?,?,?,?)");

			ps.setString(1, e.getEmp_name());
			ps.setString(2, e.getEmp_email());
			ps.setString(3, e.getEmp_pass());
			ps.setString(4, e.getEmp_desgn());
			ps.setInt(5, e.getDept_id());
			ps.setInt(6, 1);
			
			String date = e.getEmp_startdate();
			SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
			java.util.Date sd = sdf.parse(date);
			java.sql.Date sqdob = new java.sql.Date(sd.getTime());

			ps.setDate(7, sqdob);

			status = ps.executeUpdate();
			con.close();

		} catch (Exception ex) {
			System.out.println(ex);
		}

		return status;
	}

	public static Employees getEmployeeById(int id) {
		Employees empObj = new Employees();

		try {
			Connection con = EmployeeDAO.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from employees where emp_id=?");

			ps.setLong(1, id);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {

				empObj.setEmp_id(rs.getInt(1));
				empObj.setEmp_name(rs.getString(2));
				empObj.setEmp_email(rs.getString(3));
				empObj.setEmp_pass(rs.getString(4));
				empObj.setEmp_desgn(rs.getString(5));
				empObj.setDept_id(rs.getInt(6));
				empObj.setEmp_status(rs.getInt(7));
				empObj.setEmp_startdate(rs.getString(8));
			}
			con.close();

		} catch (Exception E) {
			System.out.println(E);

		}
		return empObj;
	}

	public static int insertParticipants(Employees Obj) {
		int status = 0;

		try {
			Connection con = EmployeeDAO.getConnection();

			PreparedStatement ps = con.prepareStatement("insert into participants(emp_id) values(?)");
			ps.setInt(1, Obj.getEmp_id());

			status = ps.executeUpdate();
			con.close();

		} catch (Exception ex) {
			System.out.println(ex);
		}

		return status;
	}

	public static List<Employees> getAllEmployeesByName() {
		List<Employees> list = new ArrayList<Employees>();
		try {
			Connection con = EmployeeDAO.getConnection();

			PreparedStatement ps = con.prepareStatement("select emp_name from employees");
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				Employees e = new Employees();
				e.setEmp_name(rs.getString(1));

				list.add(e);
			}
			con.close();

		} catch (Exception E) {
			System.out.println(E);
		}
		return list;
	}

	public static String getEmpName(String email, String pass) {
		String name = null;
		try {
			Connection con = EmployeeDAO.getConnection();
			PreparedStatement ps = con
					.prepareStatement("select emp_name from employees where emp_email=? and emp_pass=?");

			ps.setString(1, email);
			ps.setString(2, pass);

			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				name = rs.getString(1);
			}
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

		return name;

	}

}
